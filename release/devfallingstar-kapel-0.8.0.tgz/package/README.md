# Kapel

An orchestration-first open-source coding agent runtime.

The strongest model plans and delegates work; cheaper or specialized workers execute isolated tasks. Users define routing, concurrency, review, retry, and escalation behavior in natural language. That policy is compiled to a typed Policy IR and enforced by a deterministic scheduler.

## Quickstart

Like other terminal coding agents, `kapel` runs inside the repository you want it to work on. Install it globally from the packed tarball in this repo (identical on Windows cmd, macOS, and Linux — no build step):

```bash
npm install -g https://raw.githubusercontent.com/devFallingstar/kapel/main/release/devfallingstar-kapel-0.8.0.tgz

cd /path/to/your/repo
kapel                                 # first run asks which backend and models to use
```

`kapel` opens a prompt and stays there. **All agent work happens in that
REPL** — talking, planning, orchestrating, resuming. The commands on the shell
(`init`, `config`, `models`, `runs`, `sessions`, `explain`, `policy`) set kapel
up and inspect what it did; none of them do the work themselves.

The first time you run `kapel` on a terminal it asks five questions — which
coding backend (Claude Code, Codex, or a plain API key) and which model to use
for the orchestrator and for each of the three worker tiers — and stores the
answers in
`~/.kapel/config.json`. See [First-run setup](#first-run-setup). Piped,
redirected or `--no-setup` runs skip it and fall back to environment variables
and defaults, so nothing in CI ever blocks on a prompt.

Once published to the npm registry this becomes simply `npm install -g @devfallingstar/kapel`.
If the tarball URL is unreachable from your network, the equivalent two-step
form is `git clone
https://github.com/devFallingstar/kapel.git kapel-src && npm install -g
./kapel-src/release/devfallingstar-kapel-0.8.0.tgz`.

> Do not use `npm install -g github:...` — npm's git-dependency preparation
> mishandles workspace monorepos and produces a broken install.

For development, clone and run `npm install && npm run build`, then use `node apps/cli/dist/index.js` or `npm install -g .` from the repo root.

### The REPL

`kapel` opens a conversation with the agent, in the directory you ran it from — the same way `claude`, `codex` or `opencode` do. Type, the agent works with its tools, and the conversation keeps going:

```text
$ kapel
kapel v0.8.0  claude-sonnet-5  session 0f3c9a2b
/path/to/your/repo
type /help for commands, /exit to quit
\ + Enter for multiline input, ↑/↓ to recall, tab-complete /commands and @files

kapel> calc.test.js is failing — find out why and fix it
→ read_file {"path":"calc.test.js"}
  ✓
→ grep {"pattern":"function add"}
  ✓
  calc.js
  - return a - b;
  + return a + b;
  a = always allow edit_file this session
allow edit_file? [y/n/a] y
  ✓
`add` subtracted instead of adding. Fixed and `node calc.test.js` now prints PASS.
tokens +4210 in, +318 out  (~$0.0138)

kapel> now add a `sub` function next to it, with a test
…
kapel> /exit
```

Read-only tools (`read_file`, `glob`, `grep`, `git_diff`) run without asking; anything that writes or shells out asks first, and Ctrl-C at a question answers "no". The question is what will happen, not a truncated blob of JSON: `bash` shows the command it will run, `edit_file` a `-`/`+` diff of the replacement, `write_file` the head of the new file. Answers are `y` (allow this once), `n`/Enter/Ctrl-C (deny), or `a` — allow it and stop asking for the rest of the session: for `bash` that remembers the *command prefix* (answering `a` to `npm test --run foo` stops asking for `npm test …`, while `npm publish` still asks; a command with a shell operator such as `&&` or `|` is never remembered), and for every other tool it remembers the tool name. Nothing is written to disk — a new `kapel` starts asking again — and an explicit deny rule is never overridden by it. (Under `--backend codex` or `--backend claude-code` the external CLI runs the tools and enforces its own approvals, so kapel does not prompt at all — the banner says so.) Ctrl-C during a turn cancels that turn without ending the conversation; at the prompt, twice in a row exits (so does `/exit` and Ctrl-D).

The agent's reply appears as it is generated, a token at a time, rather than landing whole when the turn finishes. While it is thinking, or a tool is running, a single self-updating line at the bottom shows a spinner, how long the current wait has been, and the conversation's token count so far. That line is a terminal courtesy and nothing else: piping or redirecting `kapel` gets plain text with no spinner and no control characters in it.

The prompt is a real input editor, not a one-shot readline: end a line with `\` (or paste a multi-line block) to keep composing before you send it — a blank line or a line with no trailing `\` ends it. ↑/↓ recall earlier messages, persisted across sessions in `~/.kapel/history` (last 1000, machine-wide). Tab completes what is under the cursor: a `/` command name, the argument of a command that has a fixed vocabulary (`/model ` offers the built-in aliases), or an `@` file mention.

**`@` mentions a file.** Type `@` and part of a path, then Tab: the match is fuzzy over the whole path, so `@clisrc` finds `apps/cli/src/…` and `@input.ts` finds it wherever it lives. A unique winner is filled in; several share whatever prefix they have in common, and pressing Tab again lists them. The candidates are the workspace's files as `git ls-files --cached --others --exclude-standard` reports them — tracked files plus untracked ones your `.gitignore` does not exclude — cached for a few seconds so holding Tab down does not spawn a process per keystroke. Outside a git repo the list comes from a bounded walk instead (four levels deep, `node_modules`/`.git`/`dist` skipped).

The mention stays plain text in your message. When the message is sent, every `@` token that names a real file inside the workspace is collected into one extra line:

```text
kapel> why is @apps/cli/src/input.ts holding stdin the whole time?

  …sent as…
  why is @apps/cli/src/input.ts holding stdin the whole time?

  [mentioned files: apps/cli/src/input.ts]
```

The file's *contents* are never pasted in — the agent has `read_file` and decides for itself how much of the file it needs, which keeps the context window for the conversation instead of for bytes nobody asked for. A token that names nothing (`@here`, an email address, a path outside the directory you opened `kapel` in) is left alone and reported to nobody.

Commands available at the prompt:

| command | what it does |
|---|---|
| `/help` | list these commands |
| `/exit`, `/quit` | leave the session |
| `/new` | start a fresh conversation in this directory |
| `/sessions` | list this directory's conversations (id, name, last touched, messages, title) |
| `/resume <id\|name>` | switch to a stored conversation — a unique id prefix or a `/name` both work |
| `/name` / `/name <name>` | show, or set, this conversation's name — persists immediately |
| `/fork` / `/fork <name>` | branch this conversation (everything said so far) into a new session and switch to it |
| `/model` / `/model <alias>` | show, or switch, the model used for the turns that follow |
| `/config` | re-run setup and apply it to this conversation — switches backend and/or model without losing the thread |
| `/usage` | tokens and cost so far |
| `/compact` | compact the conversation history now (native backend only) |
| `/undo` | put the files back the way they were before the last prompt |
| `/plan "<objective>"` | plan an objective into a task graph and show it, with the routing rationale — nothing is executed; see [Orchestrate](#orchestrate) |
| `/orchestrate "<objective>"` | plan it *and* run it across routed workers; see [Orchestrate](#orchestrate) |
| `/runs` | list this workspace's recorded orchestration runs, newest first |
| `/resume-run <runId>` | finish the tasks a recorded run never completed (the id comes from `/runs`) |
| `/<name>` (custom) | run a command from `.agent/commands/<name>.md`; see below |

`/resume` and `/resume-run` are deliberately different commands: one switches
this REPL onto a stored *conversation*, the other re-executes an unfinished
orchestration *run*. Two kinds of id, two names — a single command that guessed
which you meant would be wrong at the worst possible moment.

Anything else you type is a message to the agent.

**Custom commands from `.agent/commands/*.md`.** A file there defines `/<name>` (the name is the filename, lowercase letters/digits/hyphens only — e.g. `.agent/commands/review.md` becomes `/review`). The file is an optional YAML front matter block followed by a prompt template:

```markdown
---
description: Review the current diff for bugs, then summarize risk
model: claude-haiku-4-5
---
Review the current diff for bugs, correctness issues, and anything unfinished.

$ARGUMENTS
```

`description` shows up in `/help`. `model` pins *this one turn* to that model (native backend only — on a delegated backend, or an alias that doesn't resolve, kapel prints one line saying the pin was skipped and runs on the session's current model instead); the session's own model is unaffected before or after. `agent` is parsed but reserved for a future sub-agent dispatch and does nothing yet. Whatever you type after the command name replaces every `$ARGUMENTS` in the template, or — if the template has no placeholder — gets appended after a blank line. The expanded text is sent exactly like a typed message: checkpoints, `@` mentions and history all apply normally. A file whose name collides with a built-in command (`/help.md`, say) is skipped in favor of the built-in, with a warning printed by `/help`; commands are scanned once at startup and rescanned on every `/help`, so adding a file mid-session doesn't need a restart. `kapel init` ships one example, `.agent/commands/review.md`.

On the native backend, a long conversation compacts itself automatically once it passes 60 messages — old tool results get elided (kept ones are marked, nothing is dropped from the transcript), leaving one dim `≈ context compacted: …` line — so it keeps going instead of eventually blowing the model's context window. `/compact` does the same thing on demand, useful right before a turn you want as much context budget for as possible. Under `--backend codex` or `--backend claude-code` the external CLI manages its own context, so `/compact` there just says it isn't supported.

**`/undo` — a checkpoint before every prompt.** The interactive agent writes straight to your files, with no worktree between you and it, so kapel takes a snapshot of the working tree just before each message is sent (slash commands change nothing, so they take none) and `/undo` restores the newest one: `↩ restored 3 files to before "fix the tests" (2 min ago)`. The snapshot is a git tree object built against a *temporary* index — your index, your worktree and your stash list are never touched — which means it covers untracked files too, not only the ones `git stash` would see. Restoring diffs that snapshot against the tree as it is now and reverses the difference: files the turn changed are rewritten, files it created are deleted, files it deleted come back.

Read the fine print before you rely on it:

- **git only.** Outside a git repository nothing is captured and `/undo` says so — full-directory copies of an arbitrary working directory are not a trade kapel is willing to make on your behalf.
- **It reverts the file, not the author.** Everything that changed since the checkpoint goes back, whoever changed it — the agent's `edit_file`, a `bash` command it ran, your own editor in another window, a build that wrote into the tree. If a turn ran that long, look before you undo.
- **Scope.** The snapshot covers the whole repository the working directory belongs to, minus anything `.gitignore` excludes (`node_modules/`, build output, `.env`) and minus `.agent/`, which holds kapel's own session database and task worktrees. Those are never captured and never restored.
- **One-way, and only for this process.** There is no `/redo`: an undone checkpoint is popped. The last 20 checkpoints of a session are kept, in memory only — quitting kapel forgets them. The commit objects behind them stay in the repository unreferenced (`git show <hash>` still works if you noted one down) until git's own garbage collection eventually prunes them.
- **Refusals.** `/undo` will not run while a merge, rebase, cherry-pick, revert or bisect is half-finished; finish or abort that first. The checkpoint stays put in the meantime.

**Sessions are per directory and survive restarts.** Every conversation is recorded in `.agent/sessions.db` beside the repo (the directory is created on first use — no `kapel init` needed), titled from your first message. Pick one back up with:

```bash
kapel chat --continue           # the most recent conversation here
kapel chat --session 0f3c9a2b   # a specific one (id, unique prefix, or /name)
kapel chat --no-save            # …or don't record this one at all
```

`kapel chat` is the explicit spelling of bare `kapel`: use it when you want those flags. The globals (`--cwd`, `-m/--model`, `--backend`, `--timeout`, `--no-setup`) work the same either way.

Images cannot be attached to a turn yet. `@` mentions name a file for the agent to read; there is no path from the prompt to an image attachment, and the `-i/--image` flag that used to exist only ever worked for a one-shot run.

### Commands on the shell

Everything outside the REPL is setup and inspection:

```bash
kapel                    # open the REPL — this is where the work happens
kapel chat               # the same thing, spelled out (--continue, --session, --no-save)
kapel init               # copy the default .agent/ configuration into this repo
kapel config             # re-run setup (--show prints it, --path prints the file path)
kapel models             # model aliases and their credential status
kapel runs               # orchestration runs recorded here (--limit, --json)
kapel sessions           # chat sessions recorded here (--limit, --json)
kapel sessions fork <id|name> [--name <name>]
kapel explain <taskId>   # how one task of a run was routed and what happened (--run, --json)
kapel policy compile | check | explain | diff
kapel help [command]     # same as --help
```

Global flags, on every command:

- `--cwd <dir>` — the workspace to operate in (default: the current directory)
- `-m, --model <alias>` — override the planner/orchestrator model (default: `AGENT_MODEL`, then your stored config, then `claude-sonnet-5`)
- `--backend <native|codex|claude-code>` — override the execution backend; see [First-run setup](#first-run-setup) for what happens when nothing overrides it
- `--timeout <seconds>` — model call timeout
- `--no-setup` — never run the first-run wizard; use environment variables and defaults instead

`--json` is not global. It lives on the commands that actually emit machine-readable output — `runs`, `sessions`, `sessions fork`, `explain`, and each `policy` subcommand — and nowhere else.

A command that no longer exists gets the same terse answer as a typo:

```text
$ kapel plan "add a health endpoint"
error: unknown command 'plan'
```

### First-run setup

`kapel` needs to know two things before it can do anything: how to talk to a
model, and which models to use. On a terminal it asks once, on the first run of
any command that needs an answer, and stores what you say in
`~/.kapel/config.json` (`$KAPEL_CONFIG_DIR` overrides the directory):

```text
Which coding backend should kapel use?
❯ ◉ Claude Code (use your Claude Code subscription login — no API key)
    ◯ Codex (use your ChatGPT login via the OpenAI Codex CLI — no API key)
    ◯ API key (Anthropic/OpenAI) (call model APIs directly with a key or token)
```

…followed by the orchestrator model and the three worker models — the complex
tier (the hardest coding work), the everyday tier, and the small-task tier
(single-function changes and exploration). The chosen backend is probed as you
pick it, so a missing or logged-out CLI is reported there and then rather than
on your first objective.

```bash
kapel config            # re-run the wizard at any time
kapel config --show     # what is configured, and where the file lives
kapel config --path     # just the path
kapel --no-setup "…"    # never ask; use environment variables and defaults
```

Inside the interactive agent, `/config` runs the same wizard and applies the
answers to the conversation you are already in — the thread is kept, only the
turns that follow change backend or model.

**Everything resolves in one order**, wherever a backend or a model is chosen
(the REPL, `/plan`, `/orchestrate`, `policy compile`):

```text
explicit CLI flag  >  environment variable  >  ~/.kapel/config.json  >  detected  >  built-in default
     --backend            AGENT_BACKEND              backend                            native
     -m/--model           AGENT_MODEL                models.orchestrator                claude-sonnet-5
```

**Backend auto-detection** fills the gap in the last step but one. If nothing
has chosen a backend — no `--backend`, no `AGENT_BACKEND`, no stored config
(a `--no-setup` run, a piped one, a machine whose config was never written) —
kapel looks for one that actually works instead of assuming `native` and
failing on a missing credential: a logged-in Claude Code CLI first, then a
logged-in Codex CLI, then a provider credential in the environment. Whatever it
finds is announced in one line on stderr and used for that process:

```text
backend: claude-code (auto-detected — set one with `kapel config`)
```

The probe runs at most once per process, and never at all when anything above
it in the order has an answer. With nothing usable found, `native` stands, in
silence — at that point the thing worth hearing about is the missing
credential, not the detection.

`.agent/config.yaml` is a separate, per-project thing: it says which model each
*agent* of an orchestration run uses. `kapel init` seeds it from your global
config when you have one (`lead` and `reviewer` from the orchestrator model,
`complex`, `worker` and `cheap` from the three worker models), and copies the
template unchanged when you don't.

### Permissions

`write_file`/`edit_file`/`bash` ask at the prompt (`[y/n/a]` — "a" remembers the
answer for the rest of that session only, never written anywhere). There is no
flag to turn the asking off: the REPL is the one place a human is definitely
present. A `permission` block, hand-edited into either config file, changes what
asks and what doesn't — opencode's syntax, unchanged:

```jsonc
// ~/.kapel/config.json
{
  "version": 1, "backend": "…", "models": { "…": "…" },
  "permission": {
    "edit_file": "allow",
    "bash": { "*": "ask", "git *": "allow", "rm *": "deny" }
  }
}
```

```yaml
# .agent/config.yaml — same shape, applies to this project only
permission:
  edit_file: allow
  bash:
    "*": ask
    "git *": allow
    "rm *": deny
```

Each tool's value is `"allow" | "ask" | "deny"`, except `bash`, whose value is
a map of command patterns to verdicts: `"*"` is the catch-all, `"git *"`
matches any `git` subcommand, `"git log *"` matches only `git log`, and a bare
`"git"` matches only `git` with no subcommand at all — the most specific
pattern that matches wins, and an explicit `"deny"` always wins a tie.

Precedence: built-in defaults, then `~/.kapel/config.json`, then
`.agent/config.yaml` — each layer only needs to mention what it wants to
change. A `"deny"` from any of these three cannot be talked around by
answering "a" at the prompt; it never reaches the prompt at all. There is no
`/config` UI for this yet — edit the file, restart the run. Neither file needs
a `permission` block; both work exactly as before without one.

### Project instructions (AGENTS.md)

Drop an `AGENTS.md` in your repo and kapel follows it from the first turn — the same file Codex and opencode already read, and that Claude Code picks up via `@AGENTS.md` imports, so a repository only has to write its rules once. Up to three are merged into the system prompt, machine-level first so a project's rules add to (never silently lose to) your personal ones:

1. `~/.kapel/AGENTS.md` (`$KAPEL_CONFIG_DIR` overrides the directory) — your own rules, for every project.
2. `AGENTS.md` at the repo root — project rules, shared with other agents.
3. `.agent/AGENTS.md` — kapel-specific overrides.

All that exist are concatenated in that order; a missing file is simply skipped. The REPL's banner names whichever were loaded (`instructions: AGENTS.md, .agent/AGENTS.md`). The combined text is capped at 32 KiB. Delegated backends (`--backend codex`, `--backend claude-code`) run the external CLI's own agent loop, which does not take a system prompt from kapel — those AGENTS.md files are not injected there, though the CLIs themselves may already read AGENTS.md-style files on their own.

### Claude Code backend

Want Claude models without an `ANTHROPIC_API_KEY`? Pass `--backend claude-code`
(or set `AGENT_BACKEND=claude-code`, or pick it in the wizard) to delegate the
work to Anthropic's own Claude Code CLI, under your existing subscription
login:

```bash
npm install -g @anthropic-ai/claude-code
claude                            # once, to log in with your Claude subscription
kapel --backend claude-code       # …and open the REPL on it
```

Pick it once in `kapel config` and the flag stops being necessary; with neither, kapel detects a logged-in `claude` on its own (see [First-run setup](#first-run-setup)).

`kapel` never touches Anthropic's OAuth flow or Claude Code's credentials on
this path — it spawns `claude -p` in the workspace and renders the stream it
prints. `-m/--model` (or your configured orchestrator model) is forwarded to
`--model`, which takes both aliases (`opus`, `sonnet`, `haiku`) and full model
ids; `default` means "whatever your account defaults to" and is not forwarded.
Permission prompts do not apply here — Claude Code enforces its own approvals,
which the interactive banner says out loud.

**Conversations continue on Claude Code's side.** The first turn runs plain;
every turn after it passes `--resume <session_id>` with the id Claude Code
reported, so the thread lives in the CLI rather than being re-sent. Resuming a
stored conversation from the database (`kapel chat --continue`) replays the
transcript once on the first turn and continues by id from there. Codex chats
are stateless instead — `codex exec --json` does not report a resumable id —
so each Codex turn carries the recent transcript with it.

**Orchestration runs on it too.** `/orchestrate` under this backend
spawns one `claude -p` per task, in that task's own workspace (its worktree —
isolation is always on), on the model the routed agent
declares in `.agent/agents/*.md`. Unlike Codex, Claude Code can be scoped per
run, so each agent's `tools:` list is translated into `--allowedTools` —
a reviewer really does run without `Write` and `Edit`. Approvals stay Claude
Code's own (`acceptEdits`), and the project's `validation:` commands gate
mutating tasks here just as they do on the native loop.

### Authentication

Any of these can also go in a `.env` file in the workspace instead of the shell environment.

**Anthropic** — checked in this order, first match wins:

1. `ANTHROPIC_API_KEY` — a standard API key.
2. `ANTHROPIC_AUTH_TOKEN` — a pre-issued bearer token, e.g. from an org that fronts Anthropic with its own auth.
3. An OAuth profile from the Anthropic CLI — run `ant auth login` once, and `kapel` picks up a short-lived access token from it automatically. No env var needed.

`ANTHROPIC_BASE_URL` overrides the API endpoint (for gateways/proxies) under any of the three.

**OpenAI** — `OPENAI_API_KEY` only. OpenAI does not offer third-party OAuth for direct API access; if your organization fronts OpenAI with its own OAuth-authenticated gateway, point `OPENAI_BASE_URL` at it and keep using `OPENAI_API_KEY` for whatever credential that gateway expects.

### Codex backend

Want OpenAI models without an `OPENAI_API_KEY`? Pass `--backend codex` (or set `AGENT_BACKEND=codex`) to delegate the objective to OpenAI's own Codex CLI instead of the native provider loop:

```bash
npm install -g @openai/codex
codex login                 # ChatGPT OAuth — no API key
kapel --backend codex       # …and open the REPL on it
```

`kapel` never handles OpenAI credentials itself on this path — it just spawns `codex exec --json` in the workspace and lets Codex authenticate and run its own agent loop. `-m/--model` is forwarded to Codex only when you pass it explicitly; otherwise Codex picks its own default. Codex runs under its `workspace-write` sandbox with `--full-auto`, so it doesn't stall on approval prompts; kapel's own permission prompts don't apply here — Codex enforces its own approvals via the sandbox. As with Claude Code, picking it in `kapel config` makes the flag unnecessary, and a logged-in `codex` is detected when nothing else has chosen.

### Policy

`.agent/orchestration.md` is your routing/concurrency/review/retry/escalation policy, written in plain English. The CLI compiles it to a typed, deterministic IR:

- `kapel policy compile` — uses an LLM (same backend/model resolution as a run; `-m/--model` selects the model, `--backend` decides whether it goes through an API key or your Codex/Claude Code login) to compile `orchestration.md` into `.agent/orchestration.lock.json`, reporting any warnings (judgement calls) or ambiguities (source phrases it couldn't map). Each warning/ambiguity that quotes a source phrase is annotated with the `orchestration.md:12` line (or `:12-13` when the phrase wraps lines) it was found at — best-effort: a phrase the compiler paraphrased instead of quoting carries no location, never a wrong one. `--json` adds parallel `warningLocations`/`ambiguityLocations` arrays (`null` where unresolved). The text output also prints what the compile spent; on a delegated backend that is whatever the CLI reported, and "none reported" when it reported nothing rather than a misleading `0`.
- `kapel policy check` — a fast, offline gate: confirms the lock still matches `orchestration.md` and the current agents, without calling an LLM. Good for CI.
- `kapel policy explain` — prints a human-readable summary of the locked policy from the lock file, also without calling an LLM. Same line-annotated warnings/ambiguities as `compile`.
- `kapel policy diff` — recompiles `orchestration.md` (one LLM call, same resolution as `compile`) and diffs the result against the current lock **without writing it**, so you can review a change before committing to it: routing/review/escalation rules added, removed, or changed field-by-field (matched by each rule's own `id`, not its position — reordering a policy's rules between compiles is not a change), plus any changed defaults (`orchestrator`, `maxConcurrency`, `parallelizeIndependentTasks`, `defaultMaxAttempts`). `--json` emits `{ok, unchanged, defaults, routing, review, escalation, warnings, ambiguities}`. "Same resolution as `compile`" includes the backend: under `--backend codex`/`--backend claude-code` the recompile is delegated to that CLI, so `diff` needs no API key either.

All four accept `--cwd`, and each takes its own `--json`.

### Orchestrate

A message at the prompt runs one model in one loop. `/orchestrate` runs the full M3 pipeline instead: the objective is **planned** into a task DAG, the plan is **rewritten by your compiled policy** (unknown agents dropped, mandated reviews injected, unrunnable plans rejected), and the resulting tasks are **routed to different workers and executed in parallel** by the deterministic scheduler.

```bash
kapel policy compile     # once, on the shell, and after every orchestration.md edit
```

```text
kapel> /plan add a health endpoint          ← preview the task graph — no work is done
kapel> /orchestrate add a health endpoint   ← plan, then execute it
kapel> /runs                                ← what has been run here
kapel> /resume-run 0f3c9a2b                 ← finish a run that stopped part-way
```

Both `/plan` and `/orchestrate` require a fresh `.agent/orchestration.lock.json` and refuse to guess: a missing or stale lock is an error telling you to run `kapel policy compile`. It is reported in the REPL and the conversation carries on. The planner itself runs on the model your policy's orchestrator agent is configured with (`-m/--model` overrides it; if that agent or its credential is unavailable, kapel falls back to the normal default model and says so).

Under `--backend codex` or `--backend claude-code` the planning conversation is delegated to that CLI too, so **planning needs no API key either** — it runs as one read-only `codex exec --sandbox read-only` / `claude -p --permission-mode plan` call in your workspace, on the orchestrator agent's configured model (or whatever `-m/--model` names, verbatim), and the plan it replies with is validated against the same schema and the same rules as on the native path.

`kapel policy compile` is delegated the same way on those backends — the same single read-only call, the same IR schema, the same warnings and ambiguities in the lock — on whatever model your `orchestrator` setting names (`-m/--model` > `AGENT_MODEL` > `~/.kapel/config.json`), or the CLI's own default when nothing names one, in which case the lock records it as `<codex default>`/`<claude-code default>`. `kapel policy diff` recompiles through the same delegated path. **So the whole pipeline — compile, diff, plan, orchestrate — runs on a Codex or Claude Code subscription with no API key anywhere.**

`/plan` prints one row per task — id, type, complexity, the agent the router would pick, dependencies, title — plus any reviews the policy injected and any notes from the rewrite.

It then prints the **routing rationale** for every task, always: the same `PolicyRouter.decide` the scheduler itself runs at execution time, saying which rule matched (its match criteria, strength and weight) or, with no matching rule, whether it fell back to the task's `suggestedAgent` or the policy's orchestrator — plus the model alias the picked agent is configured with. This used to be a `--why` flag you had to remember; at a prompt the table and the reason behind it are one thought.

During a run, task lifecycle lines are interleaved with the workers' own output:

```text
▶ T01 → explorer (attempt 1)
⎇ T02 worktree created (agent-task/8f3a.../T02)
▶ T02 → coder (attempt 1)
✔ T02 — Added the /healthz route.
⇡ T02 merged → 4b1c9de0
↑ T03 rerouted coder → lead
⊘ T04 (dependency-failed)
```

The run ends with a per-task status table and token/cost totals, and exits `0` only if every task completed.

How a run executes is decided by your configuration, not by flags:

- **Workers run in this process**, through the native agent loop, on the model each agent declares in `.agent/agents/*.md` (resolved via the `models:` aliases in `.agent/config.yaml`). **Independent tasks fan out to different configured workers**: with a policy that routes `exploration` to your explorer agent and `implementation` to your coder agent, those two tasks run concurrently on two different models.
- **Under a delegated backend, every task goes to that CLI instead.** `codex` (see [Codex backend](#codex-backend)) or `claude-code` (see [Claude Code backend](#claude-code-backend)): one `claude -p` per task in that task's workspace, on the agent's configured model, with the agent's `tools:` list passed through as `--allowedTools`. Claude Code enforces its own approvals (`acceptEdits`), and validators still run.
- **Worktree isolation is on**, always — see [Worktree isolation](#worktree-isolation) below.
- **The project's validators gate every mutating task**; see [Validation and review](#validation-and-review).
- **The run is recorded** in `.agent/sessions.db` unless the REPL was opened with `kapel chat --no-save`; see [Sessions](#sessions).
- `--timeout <seconds>` applies **per task**, not to the run as a whole.

#### Worktree isolation

Parallel workers editing one checkout would see each other's half-finished edits, so by default **every mutating task gets its own git worktree**: a private checkout of the current `HEAD` on an `agent-task/<runId>/<taskId>` branch, under `.agent/worktrees/`. The worker only ever sees that directory. When the task succeeds, its changes are committed on the task branch and merged back into your checked-out branch — merges are serialized, so concurrent tasks land one after another rather than racing. The checkout and the branch are then deleted, and the task's reported `changedFiles`/`commit` describe what actually landed.

This applies to the native loop and to `--backend codex` alike; isolation is about how tasks share the repository, not about what runs them.

- **Read-only tasks run in place.** `exploration` and `review` tasks never write, so they run directly in your workspace with no checkout and no branch.
- **Conflicts are reported, not resolved.** If a task's branch cannot be merged (two tasks touched the same lines, or the base checkout was dirty), the task comes back `partial` with the conflicting files and the branch name in its unresolved issues, and **the branch is preserved** so you can merge or inspect it by hand. Your working tree is left clean — no merge in progress, no conflict markers.
- **Failed tasks keep their evidence.** A task that fails after making edits still has them committed on its branch, which is kept for inspection; nothing is merged.

Worktree isolation needs the workspace to be a git repository with at least one commit; if it isn't, `/orchestrate` says so before spending a model call on a plan. Should a run be killed mid-flight, leftover checkouts and `agent-task/*` branches can be cleaned up with `git worktree prune` plus `git branch -D`.

#### Validation and review

`.agent/config.yaml` can gate every mutating task on a `validation:` list:

```yaml
validation:
  - name: typecheck
    command: npm run typecheck
  - name: test
    command: npm test        # timeoutSeconds: 300  (optional, default 600)
```

Each command runs via `bash -lc` **inside the task's own worktree, before it is merged back**; a failing command fails the task (and cancels its dependents) instead of merging broken work, and its output streams as `validation.started`/`validation.completed` events. Failed and low-confidence results are retried per the policy's `escalation`/`defaultMaxAttempts` rules, rerouting to another agent when configured. Validators are skipped under `--backend codex`, since Codex reports one result per task with no hook to run a separate suite against. Separately, a policy's `review:` rules inject **blocking** review tasks for matching risk categories — a rejected verdict fails the task (and the run) the same way a failed validator does.

#### Sessions

Every `/orchestrate` run records itself in a SQLite database at **`.agent/sessions.db`**: the objective, the policy snapshot it executed under, the post-rewrite plan, every event it emitted, and a rolling per-task summary. The run id is printed as the run starts (`Run 0f3c… — 3 tasks, up to 4 at a time`) — that is what the commands below take.

```text
kapel> /runs                   ← what has been run here, newest first
kapel> /resume-run 0f3c…       ← finish the tasks that never succeeded
```

```bash
kapel runs                     # the same listing, from the shell (--limit, --json)
kapel explain T03              # why T03 ran where it ran, and what happened to it
kapel explain T03 --run 0f3c…  # …in a specific run (default: the most recent)
```

- **`/runs`** and **`kapel runs`** list id, status, start time, task counts and objective for the last `--limit` runs (default 20). `--json` (shell only) emits the same as an array. A workspace with no database yet just says so.
- **`kapel explain <taskId>`** reads one task's history back: the agent it ended on and how many attempts it took, the routing decision re-derived by running the router over the run's own policy snapshot (naming the rule that matched, or the `suggestedAgent`/orchestrator fallback when none did), and a chronological digest of the decisions made about it — held behind a conflicting task, started, escalated, low confidence, failed validators, merged or conflicted worktree, completed, cancelled. `--json` gives `{task, agent, attempts, events, route}`.
- **`/resume-run <runId>`** rebuilds the run's task graph, marks everything that already succeeded as done, and re-executes the rest into the *same* run — events keep accruing and the final status is updated in place. It runs under the **policy snapshot recorded with the run**, not the current lock: the remaining tasks were planned and routed under the original constraints, and swapping the rules half way through would produce a run that never existed under any one policy. If the project's lock has moved on since, it says so and carries on; to plan under the new policy, start a fresh `/orchestrate`. Isolation, validators and the backend are whatever `/orchestrate` itself would use.

Conversations live in the same database, in their own tables — `/sessions` and `kapel chat --continue` read those, `/runs` reads the orchestration runs above. See [The REPL](#the-repl). Outside the REPL, `kapel sessions` lists them the same way `kapel runs` lists orchestration runs, and `kapel sessions fork <id|name> [--name <name>]` copies one — its title, model and whole transcript so far — into a brand new session that then evolves independently of the one it was forked from:

```bash
kapel sessions                                # this workspace's chat sessions, newest-touched first
kapel sessions fork 0f3c…                     # copy a conversation into a new, unnamed session
kapel sessions fork 0f3c… --name "plan b"     # …and name the copy
```

`kapel sessions` shows a `NAME` column once any listed session has one; a session picks up a name by being forked with `--name`, or from `/name` at the prompt (see the command table above — it persists immediately, no need to wait for the next message). `kapel sessions fork` and `--session` everywhere they appear (`kapel chat --session`, `/resume`) resolve `<id|name>` in this order: an exact id, then a unique id prefix, then an exact name — if two sessions share a name the most recently touched one is used and a note is printed to stderr. `--json` on either `sessions` command emits the same fields as an array/object instead of a table/line.

`/fork [name]` at the prompt does the same copy `kapel sessions fork` does, but from inside the REPL and on the conversation you're already in: it branches everything said so far into a new session and switches you onto it immediately (the original stays put, unaffected, with its own history up to the fork point). Useful for "let me try a different approach without losing where I was" — `/fork before-refactor`, try the risky thing, `/resume` back to the original if it doesn't pan out.

`kapel chat --no-save` skips persistence entirely — for the conversation and for anything `/orchestrate` runs from it, so nothing is written and those runs cannot be listed, explained or resumed afterwards. Persistence is also skipped silently in a workspace with no `.agent` directory, and a store that cannot be written to never fails a run: recording a run is an observer of it, not a participant. If you'd rather not commit the database, add `.agent/sessions.db*` to your `.gitignore`.

## Project plan

The current v0.1 development plan is available in:

- [`docs/PROJECT_PLAN.md`](docs/PROJECT_PLAN.md) — source-of-truth development plan
- [`docs/PROJECT_PLAN.docx`](docs/PROJECT_PLAN.docx) — formatted document version


## Architecture

```text
Natural-language policy
        ↓
Policy compiler → Policy IR
        ↓
Planner → proposed task DAG
        ↓
Policy validator/router
        ↓
Deterministic scheduler
        ↓
Isolated workers (Git worktrees / sandbox)
        ↓
Validation / review / merge
```

## Stack

- Node.js 24 LTS
- TypeScript, strict mode, ESM
- npm workspaces
- Zod for runtime schemas
- SQLite + Drizzle for durable sessions (`.agent/sessions.db`)
- Ink/React for the terminal dashboard
- Git worktrees for parallel worker isolation
- JSONL events / JSON-RPC for integrations

## Packages

- `@agent/ai` — model/provider abstraction
- `@agent/core` — shared agent and tool primitives
- `@agent/policy` — natural-language policy IR and validation
- `@agent/orchestration` — task DAG, router and deterministic scheduler
- `@agent/workspace` — local/worktree execution isolation
- `@agent/protocol` — typed runtime events
- `@agent/session` — session persistence contracts and the SQLite/Drizzle store
- `@agent/plugin` — extension API contracts
- `@agent/coding-agent` — top-level runtime facade
- `@agent/tui` — terminal UI shell
- `apps/cli` — executable CLI

## First milestone

The first usable milestone should support:

1. one provider and a single-agent tool loop;
2. typed task planning;
3. natural-language policy compilation;
4. DAG scheduling and model routing;
5. isolated Git-worktree workers;
6. review/retry/escalation;
7. JSONL events and a basic terminal UI.

See `docs/ARCHITECTURE.md` and `docs/IMPLEMENTATION_PLAN.md`.
